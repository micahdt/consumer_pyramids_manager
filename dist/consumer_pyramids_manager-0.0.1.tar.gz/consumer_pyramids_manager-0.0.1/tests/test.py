from consumer_pyramids_manager import foreman
foreman()